char *game_print_GameState(const GameState t);
GameState game_scan_GameState(const char *s);

char *game_print_seats(const seats t);
seats game_scan_seats(const char *s);

char *game_print_Whence(const Whence t);
Whence game_scan_Whence(const char *s);

char *game_print_Konging(const Konging t);
Konging game_scan_Konging(const char *s);

char *game_print_Claims(const Claims t);
Claims game_scan_Claims(const char *s);

char *game_print_GameFlags(const GameFlags t);
GameFlags game_scan_GameFlags(const char *s);

