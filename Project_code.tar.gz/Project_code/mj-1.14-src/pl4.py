import ga_player
import sys
#ga_player.get_inits(float(sys.argv[1]),float(sys.argv[2]),float(sys.argv[3]),float(sys.argv[4]))
ga_player.ga_player_run(4,'player4')
