char *tiles_print_TileSuit(const TileSuit t);
TileSuit tiles_scan_TileSuit(const char *s);

char *tiles_print_TileWind(const TileWind t);
TileWind tiles_scan_TileWind(const char *s);

char *tiles_print_TileDragon(const TileDragon t);
TileDragon tiles_scan_TileDragon(const char *s);

char *tiles_print_TileFlower(const TileFlower t);
TileFlower tiles_scan_TileFlower(const char *s);

char *tiles_print_TileSeason(const TileSeason t);
TileSeason tiles_scan_TileSeason(const char *s);

