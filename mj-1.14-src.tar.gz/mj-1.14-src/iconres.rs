#include <windows.h>
1234 ICON "icon.ico"
